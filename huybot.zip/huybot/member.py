import telebot
import datetime
import time
import os
import subprocess
import sys
import sqlite3
import hashlib
import requests
from flask import Flask
from threading import Thread

app = Flask(__name__)

# Route cho trang chủ
@app.route('/')
def index():
    return "BOT GIANG LY ĐANG HOẠT ĐỘNG."

# Hàm chạy ứng dụng Flask
def run_flask():
    app.run(host='0.0.0.0', port=8080)

# Chạy ứng dụng Flask trong một thread mới duck lỏ
def start_flask():
    thread = Thread(target=run_flask)
    thread.start()

bot_token = '6366172953:AAFQDM3bLT8sXLSXNGrtdpX2U2kT7_gvo6U'
bot = telebot.TeleBot(bot_token)

allowed_group_id = -1910018902

allowed_users = []
processes = []
ADMIN_ID = 5909578047

connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

# Create the users table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        expiration_time TEXT
    )
''')
connection.commit()

def TimeStamp():
    now = str(datetime.date.today())
    return now

def load_users_from_database():
    cursor.execute('SELECT user_id, expiration_time FROM users')
    rows = cursor.fetchall()
    for row in rows:
        user_id = row[0]
        expiration_time = datetime.datetime.strptime(row[1], '%Y-%m-%d %H:%M:%S')
        if expiration_time > datetime.datetime.now():
            allowed_users.append(user_id)

def save_user_to_database(connection, user_id, expiration_time):
    cursor = connection.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO users (user_id, expiration_time)
        VALUES (?, ?)
    ''', (user_id, expiration_time.strftime('%Y-%m-%d %H:%M:%S')))
    connection.commit()

load_users_from_database()

@bot.message_handler(commands=['glkey'])
def startkey(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        bot.reply_to(message, text='[✅] → BOT CHỈ HOẠT ĐỘNG TRONG NHÓM https://t.me/gianglyspam')
        return

    bot.reply_to(message, text='VUI LÒNG ĐỢI TRONG GIÂY LÁT!')

    with open('key.txt', 'a') as f:
        f.close()

    username = message.from_user.username
    string = f'GL-{username}+{TimeStamp()}'
    hash_object = hashlib.md5(string.encode())
    key = str(hash_object.hexdigest())
    print(key)
    url_key = requests.get(f'https://octolinkz.com/api?api=c157aa8421f16e5dac223852c65fe83c74bea547&url=https://giangly211.io.vn/key?key!{key}').json()['shortenedUrl']

    text = f'''
- LINK LẤY KEY BOT GL {TimeStamp()} LÀ: {url_key} -
- KHI LẤY KEY XONG, DÙNG LỆNH /key {{key}} ĐỂ TIẾP TỤC -
    '''
    bot.reply_to(message, text)

@bot.message_handler(commands=['key'])
def key(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        bot.reply_to(message, text='[✅] → BOT CHỈ HOẠT ĐỘNG TRONG NHÓM https://t.me/gianglyspam')
        return

    if len(message.text.split()) == 1:
        bot.reply_to(message, 'VUI LÒNG NHẬP KEY !')
        return

    user_id = message.from_user.id

    key = message.text.split()[1]
    username = message.from_user.username
    string = f'GL-{username}+{TimeStamp()}'
    hash_object = hashlib.md5(string.encode())
    expected_key = str(hash_object.hexdigest())
    if key == expected_key:
        allowed_users.append(user_id)
        bot.reply_to(message, 'KEY HỢP LỆ. BẠN ĐÃ ĐƯỢC GIANG LY CẤP PHÉP SỬ DỤNG LỆNH /gl')
    else:
        bot.reply_to(message, 'KEY KHÔNG HỢP LỆ VUI LÒNG KIỂM TRA LẠI !')

@bot.message_handler(commands=['gl'])
def gl(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        bot.reply_to(message, text='[✅] → BOT CHỈ HOẠT ĐỘNG TRONG NHÓM https://t.me/gianglyspam')
        return

    user_id = message.from_user.id
    if user_id not in allowed_users:
        bot.reply_to(message, text='BẠN KHÔNG CÓ QUYỀN SỬ DỤNG LỆNH NÀY !')
        return

    if len(message.text.split()) == 1:
        bot.reply_to(message, 'VUI LÒNG NHẬP SỐ ĐIỆN THOẠI CẦN SPAM !')
        return

    phone_number = message.text.split()[1]
    if not phone_number.isnumeric():
        bot.reply_to(message, 'SỐ ĐIỆN THOẠI KHÔNG HỢP LỆ !')
        return

    if phone_number in ['113', '911', '114', '115', '910','911','0343304606']:
        # Số điện thoại nằm trong danh sách cấm
        bot.reply_to(message, "BỐ MÀY THÁCH SPAM ĐƯỢC OKE ! TUỔI LOZ ")
        return

    file_path = os.path.join(os.getcwd(), "sms.py")
    process = subprocess.Popen(["python", file_path, phone_number, "120"])
    processes.append(process)
    bot.reply_to(message, f'🚀 Giang Ly Đã Gửi Yêu Cầu Tấn Công 🚀 \n+ Bot 👾: @giangly_bot \n+ Số Tấn Công 📱: [ {phone_number} ]\n+ Chủ Sở Hữu 👑: @GiangLy\n+ Website : https://giangly211.io.vn/\n+ Youtube: Gl Official')

@bot.message_handler(commands=['how'])
def how_to(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        bot.reply_to(message, text='[✅] → BOT CHỈ HOẠT ĐỘNG TRONG NHÓM https://t.me/gianglyspam')
        return

    how_to_text = '''
Hướng dẫn sử dụng:
- Sử dụng lệnh /glkey để lấy key.
- Khi lấy key xong, sử dụng lệnh /key {key} để kiểm tra key.
- Nếu key hợp lệ, bạn sẽ có quyền sử dụng lệnh /gl {số điện thoại} để gửi tin nhắn SMS.
- Chỉ những người dùng có key hợp lệ mới có quyền sử dụng các lệnh trên.
'''
    bot.reply_to(message, how_to_text)

@bot.message_handler(commands=['help'])
def help(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        bot.reply_to(message, text='[✅] → BOT CHỈ HOẠT ĐỘNG TRONG NHÓM https://t.me/gianglyspam')
        return

    help_text = '''
DANH SÁCH LỆNH:
- /glkey: LẤY KEY ĐỂ SỬ DỤNG CÁC LỆNH.
- /key {key}: KIỂM TRA KEY VÀ XÁC NHẬN QUYỀN SỬ DỤNG CÁC LỆNH.
- /gl {số điện thoại}: GỬI TIN NHẮN SMS 
- /how: HƯỚNG DẪN SỬ DỤNG.
- /help: DANH SÁCH LỆNH.
'''
    bot.reply_to(message, help_text)

@bot.message_handler(commands=['status'])
def status(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        return

    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        return
    if user_id not in allowed_users:
        return
    process_count = len(processes)
    bot.reply_to(message, f'Số quy trình đang chạy: {process_count}.')

@bot.message_handler(commands=['restart'])
def restart(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        return

    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        return

    bot.reply_to(message, 'BOT SẼ ĐƯỢC KHỞI ĐỘNG LẠI TRONG GIÂY LÁT !')
    time.sleep(2)
    python = sys.executable
    os.execl(python, python, *sys.argv)

@bot.message_handler(commands=['stop'])
def stop(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        return

    user_id = message.from_user.id
    if user_id != ADMIN_ID:
        return

    bot.reply_to(message, 'BOT SẼ DỪNG LẠI TRONG GIÂY LÁT !')
    time.sleep(2)
    bot.stop_polling()

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    if message.chat.type != 'group' and message.chat.type != 'supergroup':
        bot.reply_to(message, text='[✅] → BOT CHỈ HOẠT ĐỘNG TRONG NHÓM https://t.me/gianglyspam')

start_flask() #Phần Để Hiện Web View
bot.polling()
